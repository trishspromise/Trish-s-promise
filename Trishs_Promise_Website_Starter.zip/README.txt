TRISH'S PROMISE WEBSITE

FILES:
- index.html
- styles.css

HOW TO PREVIEW:
Open index.html in any web browser.

BEFORE PUBLISHING:
1. Replace YOUR_EMAIL_HERE with the rescue email.
2. Add the Facebook page link.
3. Add your approved fundraising/payment link.
4. Add real animal photos and adoption profiles.
5. Add your final mission/story.
6. If/when 501(c)(3) status changes, update the donation disclosure.

This is a simple static site and can be uploaded to many website hosts.
